from taipy.gui.custom import Page
from resource_handler import PureHTMLResourceHandler
import plotly.express as px

a = 8
b = 10
c = a + b * 2

fruits = ['apple', 'blueberry', 'cherry', 'orange']
counts = [40, 100, 30, 55]

selectd_fruit = 'apple'
selectd_count = 40

def on_change(state, var, val):
    if ((var == 'a') or (var == 'b')):
        state.c = state.a + state.b * 2

# Create a Page instance with the resource handler
page = Page(PureHTMLResourceHandler())
