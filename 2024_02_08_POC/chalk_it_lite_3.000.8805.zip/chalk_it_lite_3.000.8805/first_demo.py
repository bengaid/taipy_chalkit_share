from taipy.gui import Gui
from first_page import page as page1


gui = Gui()
gui.add_page("first", page1)
gui.run(run_browser=True, use_reloader=True)